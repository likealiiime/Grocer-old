//
//  ListViewController.h
//  Grocer
//
//  Created by Sherród Faulks on 2/21/11.
//  Copyright 2011 Soft Illuminations, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabase.h"

@interface ListViewController : UIViewController {
    FMDatabase *db;
    NSMutableArray *names;
}

- (id)initWithFamily:(NSString *)theFamily inKingdom:(NSString *)theKingdom;

- (NSString *) sqlSelect:(NSString *)select;
- (NSString *) sqlConditions;

@property (nonatomic, retain, readonly) NSString *family;
@property (nonatomic, retain, readonly) NSString *kingdom;

@end
