//
//  ListViewController.m
//  Grocer
//
//  Created by Sherród Faulks on 2/21/11.
//  Copyright 2011 Soft Illuminations, Inc. All rights reserved.
//

#import "ListViewController.h"
#import "GrocerAppDelegate.h"
#import "RootViewController.h"
#import "FMResultSet.h"
#import "CustomNavigationBar.h"
#import "FoodName.h"

@interface ListViewController ()
    - (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;
    - (UITableViewCell *)createCellWithReuseIdentifier:(NSString*)identifier;
@end

@implementation ListViewController

@synthesize family=_family;
@synthesize kingdom=_kingdom;

- (id)initWithFamily:(NSString *)theFamily inKingdom:(NSString *)theKingdom {
    if ((self = [super initWithNibName:@"ListViewController" bundle:nil])) {
        _family = [theFamily retain];
        _kingdom = [theKingdom retain];
        db = ((GrocerAppDelegate *)[[UIApplication sharedApplication] delegate]).db;
        names = [[NSMutableArray alloc] init];
        FMResultSet *results = [db executeQuery:[self sqlSelect:@"id, specific, general"]];
        while ([results next]) {
            [names addObject:[[FoodName alloc] initWithId:[results intForColumn:@"id"]
                                                 specific:[results stringForColumn:@"specific"]
                                                  general:[results stringForColumn:@"general"]]];
        }
        [results close];
        return self;
    } else {
        return nil;
    }
}

- (NSString *) sqlSelect:(NSString *)select {
    return [NSString stringWithFormat:@"SELECT %@ FROM foods WHERE %@ ORDER BY (specific || general) ASC", select, [self sqlConditions]];
}
- (NSString *) sqlConditions {
    return [NSString stringWithFormat:@"kingdom = \"%@\" AND family = \"%@\"", self.kingdom, self.family];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = self.family;
    
    self.navigationItem.titleView = [[UIView alloc] initWithFrame:CGRectMake(0,0, 150,44)];
    self.navigationItem.titleView.backgroundColor = [UIColor clearColor];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0,7, 150,40)];
    label.text = self.title;
    label.textColor = [UIColor colorWithWhite:0.15 alpha:1];
    label.shadowColor = [UIColor colorWithWhite:0.78 alpha:1];
    label.shadowOffset = CGSizeMake(0, 1);
    label.textAlignment = UITextAlignmentCenter;
    label.font = [UIFont fontWithName:@"MoanHand" size:32.0];
    label.opaque = NO;
    label.backgroundColor = [UIColor clearColor];
    label.numberOfLines = 1;
    label.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    [self.navigationItem.titleView addSubview:label];
    [label release];
    
    CustomNavigationBar *customNavigationBar = (CustomNavigationBar *)self.navigationController.navigationBar;
    [customNavigationBar setBackgroundWith:[UIImage imageNamed:@"ListViewUINavigationBar"]];
    customNavigationBar.tintColor = [UIColor brownColor];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    //CGRect frame = self.navigationItem.titleView.frame;
    //self.navigationItem.titleView.frame = CGRectMake(frame.origin.x,4, frame.size.width,frame.size.height);
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [names count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"ListViewCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) cell = [self createCellWithReuseIdentifier:CellIdentifier];
    
    // Configure the cell.
    [self configureCell:cell atIndexPath:indexPath];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}

- (void)dealloc
{
    [_family release];
    [_kingdom release];
    [names release];
    [super dealloc];
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    [(UILabel *)[cell viewWithTag:1] setText:((FoodName *)[names objectAtIndex:indexPath.row]).name];
}

- (UITableViewCell *)createCellWithReuseIdentifier:(NSString*)identifier {
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
    
    UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ListViewTableCellBackground@2x.png"]];
    background.opaque = YES;
    cell.backgroundView = background;
    [background release];
    
    UIImageView *highlight = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ListViewTableCellBackgroundHighlight"]];
    highlight.opaque = YES;
    cell.selectedBackgroundView = highlight;
    [highlight release];
    
    UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(70,10, 250,25)] autorelease];
    label.tag = 1;
    label.font = [UIFont fontWithName:@"Sketchetik" size:20];
    label.textColor = [UIColor colorWithWhite:(4.0/16.0) alpha:1];
    label.backgroundColor = [UIColor clearColor];
    label.opaque = NO;
    label.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth;
    label.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    [cell.contentView addSubview:label];
    
    return cell;
}

@end